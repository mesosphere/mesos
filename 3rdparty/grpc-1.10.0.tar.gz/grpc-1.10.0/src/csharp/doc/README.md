DocFX-generated C# API Reference
--------------------------------

Install docfx based on instructions here: https://github.com/dotnet/docfx

```
# generate docfx documentation into ./html directory
$ docfx
```
